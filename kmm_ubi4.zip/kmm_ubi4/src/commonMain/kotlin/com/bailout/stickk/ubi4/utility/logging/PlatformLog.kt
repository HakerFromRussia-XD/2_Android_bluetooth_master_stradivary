package com.bailout.stickk.ubi4.utility.logging

expect fun platformLog(tag: String, message: String)