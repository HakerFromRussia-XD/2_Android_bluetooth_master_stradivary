package com.bailout.stickk.ubi4.utility

object BaseUrlUtilsUBI4 {
//    const val BASE = "https://api.motorica.org"
    const val BASE = "https://cyberops.motorica.tech:8443/"
    const val API_KEY = "8Zm6JLIPet4CX7q5Ni8Ghn3PcSSmWmsXYdG9OrVqmu6IfKtmbQ62oGA1DPO8CjSuXyLInaZQGPnRiIUQqH0yr3gPAyu4i7nnJLlE76bqJXDxoKdNJRmKAnoPJQCD9"

}