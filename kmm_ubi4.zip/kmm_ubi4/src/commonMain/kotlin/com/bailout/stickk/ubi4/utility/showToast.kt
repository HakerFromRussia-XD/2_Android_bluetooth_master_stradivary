package com.bailout.stickk.ubi4.utility

expect fun showToast(message: String)

