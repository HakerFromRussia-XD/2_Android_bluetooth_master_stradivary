package com.bailout.stickk.ubi4

class Greeting {
    fun greeting(): String = "Привет из KMM!"
}