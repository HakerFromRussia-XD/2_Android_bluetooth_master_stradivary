package com.bailout.stickk.new_electronic_by_Rodeon.models.offlineModels

data class ProfileSettings(val gesturesStateWithEncoders: ArrayList<GestureStateWithEncoders>,

                           val openChNum: Int,
                           val closeChNum: Int,
                           val correlatorNoiseThreshold1: Int,
                           val correlatorNoiseThreshold2: Int,
                           val setReverseNum: Boolean,
                           val thresholdsBlocking: Boolean,
    )
