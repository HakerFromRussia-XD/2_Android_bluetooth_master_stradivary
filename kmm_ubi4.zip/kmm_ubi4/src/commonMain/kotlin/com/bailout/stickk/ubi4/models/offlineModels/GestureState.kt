package com.bailout.stickk.new_electronic_by_Rodeon.models.offlineModels

data class GestureState (val gestureNumber: Int, val openStage: Int, val closeStage: Int, val state: Int)