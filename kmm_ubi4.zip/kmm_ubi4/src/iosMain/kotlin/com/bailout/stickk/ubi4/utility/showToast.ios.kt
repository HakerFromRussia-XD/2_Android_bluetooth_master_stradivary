package com.bailout.stickk.ubi4.utility

actual fun showToast(message: String) {
    /* no-op на iOS */
}