package com.bailout.stickk.ubi4.utility

object Hyperparameters {
    const val NUM_EPOCHS = 100

    const val INDEX_START_FEATURES = 2
    const val INDEX_TARGET_STATE = 40
    const val INDEX_TARGET_ID = 41
}


