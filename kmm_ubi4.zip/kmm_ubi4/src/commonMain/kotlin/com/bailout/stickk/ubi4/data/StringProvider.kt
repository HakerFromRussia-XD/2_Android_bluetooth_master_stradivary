package com.bailout.stickk.ubi4.data

interface StringProvider {
    fun getString(key: String): String
}