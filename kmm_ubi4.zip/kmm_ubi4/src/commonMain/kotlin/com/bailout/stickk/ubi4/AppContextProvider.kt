package com.bailout.stickk.ubi4.resources.com.bailout.stickk.ubi4

interface AppContextProvider {
    fun getApplicationContext(): Any
}