package com.bailout.stickk.new_electronic_by_Rodeon.models.offlineModels

data class FingerSpeed(val numberFinger: Int, val fingerSpeed: Int)