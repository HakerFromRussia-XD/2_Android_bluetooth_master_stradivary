package com.bailout.stickk.ubi4.utility

actual fun sleep(millis: Long) {
    Thread.sleep(millis)
}