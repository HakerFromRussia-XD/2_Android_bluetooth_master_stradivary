package com.bailout.stickk.ubi4.data

//expect object PlatformStringProvider : StringProvider