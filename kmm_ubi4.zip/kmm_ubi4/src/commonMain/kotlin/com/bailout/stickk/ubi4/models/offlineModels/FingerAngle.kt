package com.bailout.stickk.new_electronic_by_Rodeon.models.offlineModels

data class FingerAngle(val numberFinger: Int, val fingerAngel: Int)